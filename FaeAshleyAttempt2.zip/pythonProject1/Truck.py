class Truck:
    def __init__(self, mileage, current_address, packages, depart_time):
        self.mileage = mileage
        self.current_address = current_address
        self.packages = packages
        self.depart_time = depart_time
        self.time = depart_time

    # def __str__(self):
    #     return f"{self.id}"
