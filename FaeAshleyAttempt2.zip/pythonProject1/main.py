# Author: Fae Ashley
# Student ID: 000532141
import csv
import datetime
import Truck
from builtins import ValueError
from HashTable import package_hash_table
from Package import Package

# Read the file containing distance information
with open("CSV/distance.csv") as csvfile1:
    distanceData = csv.reader(csvfile1)
    distanceData = list(distanceData)

# Read the file containing address information
with open("CSV/addresses.csv") as csvfile2:
    addressData = csv.reader(csvfile2)
    addressData = list(addressData)


# method to create package objects from CSV file
def loadPackageData(fileName):
    with open(fileName) as packageCSV:
        packageData = csv.reader(packageCSV)
        for package in packageData:
            try:
                pId = int(package[0])
            except ValueError:
                continue  # Skip this package and move to the next one if line is blank

            address = package[1]
            city = package[2]
            state = package[3]
            pZip = package[4]
            deadlineTime = package[5]
            weight = package[6]
            note = package[7]
            status = "At Hub"

            # Package object
            p = Package(pId, address, city, state, pZip, deadlineTime, weight, note, status, deliveryTime=None,
                        loadTime=None, truck=None)

            package_hash_table.insert(pId, p)


# Call method to create package objects from the package CSV
# Load package objects into the package_hash_table table
loadPackageData("CSV/packages.csv")


# method to use two points to find distance between two points
def findDistance(x, y):
    distance = distanceData[x][y]
    if distance == '':
        distance = distanceData[y][x]

    return float(distance)


# method to take address from package or truck and return the coordinates to be used in findDistance
def getCoordinates(address):
    for i, row in enumerate(addressData, start=0):
        if address in row[1]:
            return i


# create truck objects and load packages
truck1 = Truck.Truck(0, "4001 South 700 East", [1, 13, 14, 15, 16, 20, 29, 30, 31, 34, 37, 40],
                     datetime.timedelta(hours=8))
for truckPackage in truck1.packages:
    loadedPackage = package_hash_table.search(truckPackage)
    loadedPackage.loadTime = datetime.timedelta(hours=8)
    loadedPackage.truck = "truck 1"

truck2 = Truck.Truck(0, "4001 South 700 East", [6, 25, 3, 18, 36, 38, 2, 4, 5, 7, 8, 10, 11, 12],
                     datetime.timedelta(hours=9, minutes=5))
for truckPackage in truck2.packages:
    loadedPackage = package_hash_table.search(truckPackage)
    loadedPackage.loadTime = datetime.timedelta(hours=9, minutes=5)
    loadedPackage.truck = "truck 2"
truck3 = Truck.Truck(0, "4001 South 700 East", [9, 17, 19, 21, 22, 23, 24, 26, 27, 28, 32, 33, 35, 39],
                     datetime.timedelta(hours=10, minutes=30))
for truckPackage in truck3.packages:
    loadedPackage = package_hash_table.search(truckPackage)
    loadedPackage.loadTime = datetime.timedelta(hours=10, minutes=30)
    loadedPackage.truck = "truck 3"


# Nearest Neighbor algorithm method to deliver packages
def deliverPackages(truck):
    while len(truck.packages) > 0:
        next_address = 1000
        next_package = None
        for package_id in truck.packages:
            current_package = package_hash_table.search(package_id)
            print(current_package)
            if findDistance(getCoordinates(truck.current_address),
                            getCoordinates(current_package.address)) <= next_address:
                next_address = findDistance(getCoordinates(truck.current_address),
                                            getCoordinates(current_package.address))
                next_package = current_package

        # remove package from truck.packages list and update attributes
        truck.packages.remove(next_package.pId)
        truck.mileage += next_address
        truck.current_address = next_package.address
        truck.time += datetime.timedelta(hours=next_address / 18)
        next_package.deliveryTime = truck.time
        next_package.status = "Delivered"
    truck.mileage += findDistance(getCoordinates(truck.current_address), 0)


# call method to deliver packages on each truck to make each truck deliver packages
deliverPackages(truck1)
deliverPackages(truck2)
deliverPackages(truck3)

# User Interface
# Upon running the program, the below message will appear.
print("Western Governors University Parcel Service (WGUPS) Routing Program")
# print truck mileage
print("Total truck one mileage:")
print(truck1.mileage)
print("Total truck two mileage:")
print(truck2.mileage)
print("Total truck three mileage:")
print(truck3.mileage)
print("Total combined mileage:")
print(truck1.mileage + truck2.mileage + truck3.mileage)
# User asked to proceed with program
text = input("Would you like to inquire about packages? Please type 'yes' to proceed. ")
# Program will exit if 'yes' is not typed
if text == "yes":
    try:
        # User to designate a specific time
        timeInput = input("Please designate a time to review package data at using the following format HH:MM:SS ")
        (h, m, s) = timeInput.split(":")
        inputTime = datetime.timedelta(hours=int(h), minutes=int(m), seconds=int(s))
        # User to designate whether to display individual package or all packages at once
        packageInput = input("Would you like to review 'one' package or 'all' packages? Please type 'one' or 'all.' ")
        # proceed with one package
        if packageInput == "one":
            try:
                # User required to input package ID number to display single package
                pIdInput = input("Enter the numeric package ID: ")
                package = package_hash_table.search(int(pIdInput))
                package.updateStatus(inputTime)
                print(str(package))
            except ValueError:
                print("Entry invalid. Closing program.")
                exit()
        # If the user types "all" the program will display all package information at once
        elif packageInput == "all":
            try:
                for pId in range(1, 41):
                    package = package_hash_table.search(pId)
                    package.updateStatus(inputTime)
                    print(str(package))
            except ValueError:
                print("Entry invalid. Closing program.")
                exit()
        else:
            exit()
    except ValueError:
        print("Entry invalid. Closing program.")
        exit()
elif input != "yes":
    print("Entry invalid. Closing program.")
    exit()
