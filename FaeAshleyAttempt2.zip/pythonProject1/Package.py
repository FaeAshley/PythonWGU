class Package:
    def __init__(self, pId, address, city, state, pZip, deadlineTime, weight, note, status, deliveryTime, loadTime,
                 truck):
        self.pId = pId
        self.address = address
        self.city = city
        self.state = state
        self.pZip = pZip
        self.deadlineTime = deadlineTime
        self.weight = weight
        self.note = note
        self.status = status
        self.deliveryTime = deliveryTime
        self.loadTime = loadTime
        self.truck = truck

    def __str__(self):
        return "%s, %s, %s, %s, %s, %s, %s, %s, %s, %s" % (self.pId, self.address, self.city, self.state, self.pZip,
                                                           self.deadlineTime, self.weight, self.deliveryTime,
                                                           self.status, self.truck)

    def __call__(self, *args, **kwargs):
        return self

    def updateStatus(self, inputTime):
        if self.loadTime < inputTime:
            self.status = "En Route"
        elif self.loadTime > inputTime:
            self.status = "At hub"
            self.truck = None
        if self.deliveryTime < inputTime:
            self.status = "Delivered"
